"Calibrate Stereo Vision System (mod).vi"

This modified version of the the "Calibrate Stereo Vision System" VI that
ships with NI Vision (currently located in C:\Program Files (x86)\
National Instruments\LabVIEW 2014\examples\Vision\Stereo Vision\
Calibrate Stereo Vision System) flips the image geometry to work with cameras
mounted on the tabletop camera copy stand as shown in the image contained in
this folder. Placing the telescoping column in back makes it easier to place
objects on the baseboard (including the calibration dot grid), and also
causes the left and right camera views to "make sense" when viewing the 
objects placed on the baseboard.

