-------------------------------------------------------------------------------
NI myRIO Vision Essentials Guide
--------------------------------

Ed Doering
Professor of ECE
Rose-Hulman Institute of Technology
doering@rose-hulman.edu

Download the book and LabVIEW project templates from 
www.ni.com/myRIO/vision-guide

Revision history:
23 Jul 2015 -- Initial version
-------------------------------------------------------------------------------

Contents:

1. PDF book

2. "Machine Vision App" (MVA) LabVIEW template project; includes sample images
 
3. Calibration grids (1x1cm line grid and dot grid)

4. Modified "Calibrate Stereo Vision System" VI for the stereo vision chapter

